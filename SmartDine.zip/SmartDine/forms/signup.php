<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = mysqli_connect('localhost', 'root', '', 'credentials') or die("Connection Failed: " . mysqli_connect_error());

    // Retrieve form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    //to prevent from mysqli injection
    $name = stripcslashes($name); 
    $email = stripcslashes($email);  
    $password = stripcslashes($password); 
    $name = mysqli_real_escape_string($conn, $name);
    $email = mysqli_real_escape_string($conn, $email);  
    $password = mysqli_real_escape_string($conn, $password); 

    // Create and execute the SQL query
    $sql = "INSERT INTO users (`name`, `email`, `password`) VALUES ('$name', '$email', '$password')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo 'Entry Successful';
    } else {
        echo 'Error Occurred';
    }
    mysqli_close($conn);
}
?>
