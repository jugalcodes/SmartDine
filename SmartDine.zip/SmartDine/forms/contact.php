<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = mysqli_connect('localhost', 'root', '', 'contact') or die("Connection Failed: " . mysqli_connect_error());

    // Retrieve form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $subject = mysqli_real_escape_string($conn, $_POST['subject']);
    $message = mysqli_real_escape_string($conn, $_POST['message']);

    // Create and execute the SQL query
    $sql = "INSERT INTO users (name, email, subject, message) VALUES ('$name', '$email', '$subject', '$message')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo 'Entry Successful';
    } else {
        echo 'Error Occurred';
    }
    mysqli_close($conn);
}
?>
