<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit'])) {
        $conn = mysqli_connect('localhost', 'root', '', 'smartdine1') or die("Connection Failed: " . mysqli_connect_error());
        if (isset($_POST['name']) && isset($_POST['email']) && isset($_POST['phone']) && isset($_POST['date']) && isset($_POST['time']) && isset($_POST['people']) && isset($_POST['message'])) {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $phone = $_POST['phone'];
            $date = $_POST['date'];
            $time = $_POST['time'];
            $people = $_POST['people'];
            $message = $_POST['message'];


            $sql = "INSERT INTO users (name, email, phone, date, time, people, message) VALUES ('$name', '$email', '$phone', '$date', '$time', '$people', '$message')";

            $query = mysqli_query($conn, $sql);
            if ($query) {
                // echo 'Entry Successful';
                header("Location: payment.html"); // Redirect to payment.php
                exit(); // Make sure to exit to prevent further execution
            } else {
                echo 'Error ' . $sql . "Error";
            }
        }
    }
?>
