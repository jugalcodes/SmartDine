<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = mysqli_connect('localhost', 'root', '', 'credentials') or die("Connection Failed: " . mysqli_connect_error());

    // Retrieve form data
    
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    
    //to prevent from mysqli injection
    
    $email = stripcslashes($email);  
    $password = stripcslashes($password); 
    
    $email = mysqli_real_escape_string($conn, $email);  
    $password = mysqli_real_escape_string($conn, $password); 

    // Create and execute the SQL query
    $sql = "INSERT INTO loging (`email`, `password`) VALUES ('$email', '$password')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo 'Entry Successful';
    } else {
        echo 'Error Occurred';
    }
    mysqli_close($conn);
}
?>
