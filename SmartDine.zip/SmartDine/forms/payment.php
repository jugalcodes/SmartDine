<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = mysqli_connect('localhost', 'root', '', 'payment') or die("Connection Failed: " . mysqli_connect_error());

    // Retrieve form data
    $name = mysqli_real_escape_string($conn, $_POST['name']);
    $Month = mysqli_real_escape_string($conn, $_POST['Month']);
    $CardNumber = mysqli_real_escape_string($conn, $_POST['CardNumber']);
    $CVV = mysqli_real_escape_string($conn, $_POST['CVV']);
    

    // Create and execute the SQL query
    $sql = "INSERT INTO users (`name`, `Month`, `CardNumber`,`CVV`) VALUES ('$name', '$Month', '$CardNumber', '$CVV')";
    $query = mysqli_query($conn, $sql);

    if ($query) {
        echo 'Entry Successful';
    } else {
        echo 'Error Occurred';
    }
    mysqli_close($conn);
}
?>
